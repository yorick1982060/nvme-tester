#!/usr/bin/env python

def find_arg(args_list, str):
    """Find an argument in the argument list and return its index"""
    for i, s in enumerate(args_list):
        if str == s.split('=')[0]:
            return i
    return -1


def get_value_remove(args_list, name):
    """Get the value of an argument and remove it from the argument list"""
    idx = find_arg(args_list, name)
    if (idx != -1):
        arg_and_value = args_list[idx].split('=')
        if (len(arg_and_value) == 2):
            value = arg_and_value[1]
            del args_list[idx]
            return value

    return ""


def get_value(args_list, name):
    """Get the value of an argument without removing it"""
    idx = find_arg(args_list, name)
    if (idx != -1):
        arg_and_value = args_list[idx].split('=')
        if (len(arg_and_value) == 2):
            return arg_and_value[1]
    return ""


def is_arg_exist(args_list, name):
    """Check if the argument exists and remove it from argument list if found"""
    idx = find_arg(args_list, name)
    found = idx != -1
    if found:
        del args_list[idx]
    return found 