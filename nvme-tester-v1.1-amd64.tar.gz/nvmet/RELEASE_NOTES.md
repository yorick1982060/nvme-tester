# NVMe Tester v1.1

## New Features
- Added `--version` command to display version information

## New Test Cases
- Namespace Management Command tests
- Namespace Attachment Command tests  
- Write Zero Command tests
- Sanitize Command tests
- Format NVM Command tests
- Flush Command tests
- Device Self-Test operations (both short and extended)
- Copy Command tests
- Compare Command tests
- Device Self-Test Extended Operation abort functionality

Run "nvmet --test-info=General" to get the detailed steps for the general tests

---

# NVMe Tester v1.0

## Add test cases
- GeneralNvmWriteCommand.Case1ValidWrite
- GeneralNvmWriteCommand.Case2SLBAOutOfRange
- GeneralNvmWriteCommand.Case3NLBOutOfRange
- GeneralNvmWriteCommand.Case4SLBAOutOfRangeNLBMDTS
- GeneralNvmIdentifyCmd.Case1ValidNsidWithCns00hComprehensiveFieldValidation
- GeneralNvmIdentifyCmd.Case2InvalidNsid0h
- GeneralNvmIdentifyCmd.Case3NonExistentNsid

Run "nvmet --test-info=General" to get the detailed steps for the general tests
