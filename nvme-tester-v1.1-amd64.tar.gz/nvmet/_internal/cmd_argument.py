#!/usr/bin/env python3
"""
Command Line Argument Management Module

This module provides the CmdArgument class for handling command line argument
validation, properties, and behavior in a structured way.
"""

class CmdArgument:
    """Class to represent a command line argument with its properties and validation."""
    
    def __init__(self, name, description, is_value_needed=False, is_quick_cmd=False):
        """
        Initialize a command argument.
        
        Args:
            name: The argument name (e.g., "--version")
            description: Description of what the argument does
            is_value_needed: Whether the argument requires a value
            is_quick_cmd: Whether this is a quick command that doesn't need settings loading
        """
        self.name = name
        self.description = description
        self.is_value_needed = is_value_needed
        self.is_quick_cmd = is_quick_cmd
    
    def is_argument_valid(self, arg_string):
        """
        Validate if the argument string is properly formatted.
        
        Args:
            arg_string: The argument string from command line
            
        Returns:
            tuple: (is_valid, error_message)
        """
        # Parse argument name and value
        if '=' in arg_string:
            arg_name = arg_string.split('=', 1)[0]
            arg_value = arg_string.split('=', 1)[1]
        else:
            arg_name = arg_string
            arg_value = None
        
        # Check if this is the right argument
        if arg_name != self.name:
            return False, f"Argument name mismatch: expected {self.name}, got {arg_name}"
        
        # Check value requirements
        if self.is_value_needed:
            if arg_value is None:
                return False, f"Error: Option '{self.name}' requires a value\nUsage: {self.name}=<value>"
            elif arg_value == "":
                return False, f"Error: Option '{self.name}' requires a non-empty value\nUsage: {self.name}=<value>"
        else:
            if arg_value is not None:
                return False, f"Error: Option '{self.name}' does not accept a value\nUsage: {self.name}"
        
        return True, ""
    
    def is_quick_command(self):
        """Check if this is a quick command that doesn't need settings loading."""
        return self.is_quick_cmd
    
    def get_description(self):
        """Get the description of the argument."""
        return self.description 